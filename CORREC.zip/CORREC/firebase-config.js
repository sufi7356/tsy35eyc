// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyC97Nt7-SrygX_J-US_2PnM5ebZW9ZUE0w",
  authDomain: "hyf-9hwdf5bgv.firebaseapp.com",
  databaseURL: "https://hyf-9hwdf5bgv-default-rtdb.firebaseio.com",
  projectId: "hyf-9hwdf5bgv",
  storageBucket: "hyf-9hwdf5bgv.appspot.com",
  messagingSenderId: "675794181121",
  appId: "1:675794181121:web:476942dac995f477433400"
};